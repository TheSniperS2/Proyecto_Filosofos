package Ejercicio;

/**
 *
 * @author Franco
 */
public class Principal {
    
    public static void main(String[] args){
        Mesa m = new Mesa(5);
        for (int i = 1; i <= 5; i++){ //se crea una instancia de la clase Filosofo y se le pasan dos argumentos: la instancia de la mesa (m) y un número identificador (i).
            Filosofo f = new Filosofo(m,i);
            f.start();
            /*
            Después de crear un filósofo, se invoca el método start() en el objeto f. Esto implica que la clase Filosofo debe ser una subclase de Thread
            o debe implementar la interfaz Runnable para que pueda ser ejecutada en un hilo independiente. Al llamar al método start(),
            se da inicio a la ejecución del hilo asociado y, probablemente, esto activa cierta lógica en la clase Filosofo relacionada con la simulación de la cena de los filósofos.
            */
        }
    }
}
