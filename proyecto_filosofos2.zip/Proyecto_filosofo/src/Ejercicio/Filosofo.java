package Ejercicio;

/**
 *
 * @author Franco
 */
public class Filosofo extends Thread {
    public Mesa mesa;
    public int comensal;
    public int indiceComensal;
    
    public Filosofo(Mesa m,int comensal){
        this.comensal = comensal;
        this.indiceComensal = comensal - 1;
        this.mesa = m;
    }
    public void run(){ //se define la lógica principal del hilo del filósofo. Se ejecuta en un bucle infinito (while(true)) para simular la actividad continua del filósofo
        while(true){
            try{
                this.pensando(); //imprime un mensaje indicando que el filósofo está pensando y luego hace una pausa de 4 segundos
                System.out.println("Filosofo " + this.comensal + " esta hambriento"); //Imprime un mensaje indicando que el filósofo está hambriento
                mesa.cogerTenedor(this.indiceComensal); //en el objeto mesa, pasando el índice del comensal. Esto indica que el filósofo intenta adquirir los tenedores de la mesa
                this.comiendo(); //imprime un mensaje indicando que el filósofo está comiendo y luego hace una pausa de 4 segundos
                System.out.println("Filosofo " + this.comensal + " ha terminado de comer, tenedor libres: " + (this.mesa.tenedorIzquierdo(this.indiceComensal) + 1) + ", " + (this.mesa.tenedorDerecho(this.indiceComensal) + 1)); //Imprime un mensaje indicando que el filósofo ha terminado de comer y muestra el estado de los tenedores (libres u ocupados)
                mesa.dejarTenedor(this.indiceComensal); //en el objeto mesa, pasando el índice del comensal. Esto indica que el filósofo devuelve los tenedores a la mesa
            } catch (InterruptedException ex){ //InterruptedException en caso de interrupciones durante la pausa del hilo
                Logger.getLogger(Filosofo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void pensando() throws InterruptedException{
        System.out.println("Filosofo " + this.comensal + " esta pensando"); //Imprime un mensaje en la consola que indica que el filósofo (identificado por this.comensal) está pensando
        Thread.sleep(5000); // que suspende la ejecución del hilo actual (en este caso, el hilo del filósofo) durante 4000 milisegundos (4 segundos)
    }
        public void comiendo() throws InterruptedException{
        System.out.println("Filosofo " + this.comensal + " esta comiendo"); //Imprime un mensaje en la consola que indica que el filósofo (identificado por this.comensal) está comiendo
        Thread.sleep(5000); // que suspende la ejecución del hilo actual (en este caso, el hilo del filósofo) durante 4000 milisegundos (4 segundos)
    }
}
