package Ejercicio;

/**
 *
 * @author Franco
 */
import java.util.concurrent.Semaphore;

public class Mesa {

    private Semaphore[] Tenedor;
    // representa los tenedores en la mesa. Cada semáforo es responsable de controlar el acceso a un tenedor en particular.
    
    public Mesa(int numTenedor){
        this.Tenedor = new Semaphore[numTenedor];
        for (int i = 0; i < numTenedor; i++) {
            this.Tenedor[i] = new Semaphore(1);
        }
    }
    /*
    numTenedor que indica la cantidad de tenedores en la mesa. Dentro del constructor, se crea un arreglo Tenedor de semáforos con una longitud igual a numTenedor.
    Luego, se inicializa cada semáforo con un permiso inicial de 1, lo que significa que cada tenedor está inicialmente disponible para ser utilizado por un filósofo.
    */
    
    public int tenedorIzquierdo(int i){
        return i;
    }
    public int tenedorDerecho(int i){
        if(i == 0){
            return this.Tenedor.length - 1;
            
        }else{
            return i - 1;
        }
    }
    /*
    son métodos auxiliares que se utilizan para determinar el índice del tenedor izquierdo y derecho respectivamente,
    dado un índice de filósofo (i). Estos métodos devuelven los índices sin realizar ninguna operación compleja.
    */
    
    public void cogerTenedor(int comensal) throws InterruptedException{
        this.Tenedor[this.tenedorIzquierdo(comensal)].acquire();
        this.Tenedor[this.tenedorDerecho(comensal)].acquire();
    }
        /*
        se encarga de adquirir los tenedores izquierdo y derecho correspondientes a un comensal/filósofo específico.
        Para ello, se utiliza el método acquire() del semáforo correspondiente a cada tenedor. Si el semáforo tiene un permiso disponible,
        el filósofo adquiere el tenedor; de lo contrario, si no hay permisos disponibles, el filósofo se bloquea y espera hasta que se libere un tenedor.
        */
    public void dejarTenedor(int comensal){
        this.Tenedor[this.tenedorIzquierdo(comensal)].release();
        this.Tenedor[this.tenedorDerecho(comensal)].release();
    }
        /*
        se encarga de liberar los tenedores izquierdo y derecho que un comensal/filósofo había adquirido previamente.
        Para ello, se utiliza el método release() del semáforo correspondiente a cada tenedor,
        lo que incrementa el permiso del semáforo en 1, indicando que el tenedor está disponible para ser tomado por otro filósofo
        */
    
}
